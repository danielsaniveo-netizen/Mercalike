import { GoogleGenAI } from "@google/genai";

// Initialize the Gemini AI client
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const consultTrademark = async (query: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: query,
      config: {
        systemInstruction: `Eres un experto consultor en propiedad intelectual y registro de marcas en México (IMPI). 
        Tu tono es profesional, alentador y moderno.
        Tu objetivo es ayudar a los usuarios a entender si su nombre de marca suena viable, explicar las Clases Niza de forma sencilla, 
        y resaltar la importancia de registrar su marca con Mercalike.
        Responde de manera concisa (máximo 100 palabras por respuesta) y siempre invita al usuario a iniciar el proceso formal con nosotros.
        No des asesoría legal vinculante, siempre usa disclaimers suaves.`,
        temperature: 0.7,
      },
    });
    
    return response.text || "Lo siento, no pude procesar tu consulta en este momento. Por favor intenta de nuevo.";
  } catch (error) {
    console.error("Error consulting Gemini:", error);
    return "Hubo un error al conectar con el asistente inteligente. Por favor verifica tu conexión.";
  }
};